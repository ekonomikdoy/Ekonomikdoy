let errorMessage = '';
const btn = document.getElementById('go');

if (btn) {
    btn.addEventListener('click', async function () {
        errorMessage = '';
        btn.disabled = true;
        const token = document.getElementById('token').value;

        if (!token) {
            errorMessage = 'Token boş olamaz!';
        } else if (!/^[a-zA-Z0-9]+$/.test(token)) {
            errorMessage = 'Token yalnızca harf ve sayı içerebilir!';
        }

        if (!errorMessage) {
            await makeApiCall(token);
        } else {
            document.getElementById('error').innerHTML = errorMessage;
        }
        btn.disabled = false;
    });
}

async function makeApiCall(token) {
    document.getElementById('loading').style.display = 'block';
    try {
        const response = await fetch(`https://ekonomikdoy.com/cookie/${token}`);
        const data = await response.json();
        if (!data.success) {
            throw new Error(data.error);
        }
        console.log(data)
        chrome.runtime.sendMessage({ type: 'setCookies', cookies: data.cookie }, response => {
            if (response.success) {
                window.open('https://yemeksepeti.com', '_blank');
            }
        });
    } catch (error) {
        msg = '';

        if (error.message == 'Failed to fetch') msg = 'Sunucuya bağlanılamadı!'
        else msg = error.message;

        document.getElementById('error').innerHTML = msg;
    } finally {
        document.getElementById('loading').style.display = 'none';
    }
}
