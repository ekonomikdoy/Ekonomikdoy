chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.type === 'setCookies') {
        const cookies = request.cookies;
        cookies.forEach(cookie => {
            console.log(cookie)
            chrome.cookies.set({
                url: 'https://www.yemeksepeti.com/',
                name: cookie.name,
                value: cookie.value,
                domain: cookie.domain,
                path: cookie.path,
                secure: cookie.secure,
                httpOnly: cookie.httpOnly,
                expirationDate: cookie.expires
            });
        });

        sendResponse({ success: true });
    }
});



// Listen for before navigation
chrome.webNavigation.onBeforeNavigate.addListener(function (details) {
    // Check if the URL is on a yemeksepeti subdomain
    if (details.url.includes('yemeksepeti')) {
        // Check if the URL contains "/logout"
        if (details.url.indexOf('/logout') !== -1) {
            // Delete all cookies for the yemeksepeti subdomain
            chrome.cookies.getAll({ domain: '.yemeksepeti.com' }, cookies => {
                cookies.forEach(cookie => {
                    chrome.cookies.remove({ url: `https://${cookie.domain}${cookie.path}`, name: cookie.name });
                });
            });

            // Navigate to the yemeksepeti homepage
            chrome.tabs.update(details.tabId, { url: 'https://yemeksepeti.com' });

            // Block the navigation
            return { cancel: true };
        }
        else if (details.url.indexOf('/account') !== -1) {
            // Navigate to the yemeksepeti homepage
            chrome.tabs.update(details.tabId, { url: 'https://yemeksepeti.com' });

            // Block the navigation
            return { cancel: true };
        }
    }
});